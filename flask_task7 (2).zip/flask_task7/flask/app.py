from flask import Flask, render_template, request
import requests

app = Flask(__name__)

NEWs_API = "2ac734130fd241379e5a10e05396cb3e"
NEWS_API_URL = "https://newsapi.org/v2/everything"

@app.route('/', methods=['GET'])
def index():
    params = {
        "q": "NASA",
        "apiKey": NEWs_API  
    }
    response = requests.get(NEWS_API_URL, params=params)
    if response.status_code == 200:
        news = response.json()
    else:
        news = {"error": "Failed to retrieve data"}
    
    return render_template('index.html', pod=news)

if __name__ == '__main__':
    app.run(debug=True)